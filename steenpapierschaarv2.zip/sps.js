// Set up variables
let playerScore = 0;
let computerScore = 0;
const buttons = document.querySelectorAll('button');
const playerScoreSpan = document.querySelector('#player-score');
const computerScoreSpan = document.querySelector('#computer-score');
const result = document.querySelector('#result');

// Define a function to generate the computer's choice
function computerPlay() {
    const choices = ['rock', 'paper', 'scissors'];
    const randomIndex = Math.floor(Math.random() * choices.length);
    return choices[randomIndex];
}

// Define a function to play a single round
function playRound(playerSelection, computerSelection) {
    switch (playerSelection) {
        case computerSelection:
            return "It's a tie!";
        case 'rock':
            if (computerSelection === 'scissors') {
                playerScore++;
                playerScoreSpan.textContent = playerScore;
                return 'You win!';
            } else {
                computerScore++;
                computerScoreSpan.textContent = computerScore;
                return 'Computer wins!';
            }
        case 'paper':
            if (computerSelection === 'rock') {
                playerScore++;
                playerScoreSpan.textContent = playerScore;
                return 'You win!';
            } else {
                computerScore++;
                computerScoreSpan.textContent = computerScore;
                return 'Computer wins!';
            }
        case 'scissors':
            if (computerSelection === 'paper') {
                playerScore++;
                playerScoreSpan.textContent = playerScore;
                return 'You win!';
            } else {
                computerScore++;
                computerScoreSpan.textContent = computerScore;
                return 'Computer wins!';
            }
        default:
            return 'Invalid selection!';
    }
}

// Define a function to reset the game
function resetGame() {
    playerScore = 0;
    computerScore = 0;
    playerScoreSpan.textContent = playerScore;
    computerScoreSpan.textContent = computerScore;
    result.textContent = '';

    // Enable the game buttons and reset button
    buttons.forEach(button => button.disabled = false);
    reset.disabled = false;
}

// Add event listeners to the game buttons and reset button
buttons.forEach(button => {
    button.addEventListener('click', () => {
        const playerSelection = button.id;
        const computerSelection = computerPlay();
        result.textContent = playRound(playerSelection, computerSelection);
        if (playerScore === 5 || computerScore === 5) {
            endGame();
        }
    });
});

reset.addEventListener('click', resetGame);
